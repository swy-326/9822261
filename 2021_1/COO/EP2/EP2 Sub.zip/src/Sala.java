public class Sala {

    private String nome;
    private String local = "Nenhum local definido para esta sala";
    private Integer capacidade;
    private String observacoes = "Nenhuma observacao definida para esta sala";

    public Sala(){
    }

    // devolve o nome da sala
    public String getNome(){

        return nome;
    }

    // devolve o local da sala
    public String getLocal(){

        return local;
    }
    
    // devolve a capacidade da sala
    public Integer getCapacidade(){

        return capacidade;
    }

    // devolve as observacoes da sala
    public String getObservacoes(){

        return observacoes;
    }

    // atualiza o valor da variavel nome
    public void setNome(String nome){
        this.nome = nome;
    }

    // atualiza o valor da variavel local
    public void setCapacidade(int capacidade){
        this.capacidade = capacidade;
    }

    // atualiza o valor da variavel local
    public void setObservacoes(String observacoes){
        this.observacoes = observacoes;
    }

    // atualiza o valor da variavel local
    public void setLocal(String local){
        this.local = local;
    }
}
