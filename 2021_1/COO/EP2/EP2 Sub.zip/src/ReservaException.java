public class ReservaException extends Exception{
    public ReservaException(String msgErro){
        super(msgErro);
    }
}
