import java.time.*;

public class Reserva {
    
    private Sala sala;
    private LocalDateTime inicio;
    private LocalDateTime fim;


    public Reserva(){
    }

    // devolve o objeto sala referente a reserva
    public Sala getSala(){

        return sala;
    }

    // devolve a data de inicio
    public LocalDateTime getInicio(){

        return inicio;
    }

    // devolve a data final
    public LocalDateTime getFim(){

        return fim;
    }

    // atualiza o valor de sala
    public void setSala(Sala sala){

        this.sala = sala;
    }

    // atualiza o valor de inicio
    public void setInicio(LocalDateTime inicio){

        this.inicio = inicio;
    }

    // atualiza o valor de fim
    public void setFim(LocalDateTime fim){

        this.fim = fim;
    }
}
