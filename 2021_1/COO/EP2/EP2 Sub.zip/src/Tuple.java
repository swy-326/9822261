public class Tuple <LocalDateTime> {

	public LocalDateTime inicio;
	public LocalDateTime fim;

	public Tuple (LocalDateTime inicio, LocalDateTime fim){
		this.inicio = inicio;
		this.fim = fim;
	}

}