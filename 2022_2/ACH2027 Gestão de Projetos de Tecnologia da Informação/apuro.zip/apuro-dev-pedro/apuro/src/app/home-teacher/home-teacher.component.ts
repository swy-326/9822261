import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-home-teacher',
  templateUrl: './home-teacher.component.html',
  styleUrls: ['./home-teacher.component.scss']
})
export class HomeTeacherComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
