# Backend

- `npm i`
- `npx prisma migrate reset`
- `npm start`

# Frontend

- `npm i`
- `npm run dev
