# Daily Curious Fact

Project to Database couerse on Universidade de Sõa Paulo

## Installation

Use the package manager [pip](https://pip.pypa.io/en/stable/) to install foobar.

```bash
pip install django
```

## Usage

```python
python3 manage.py runserver
```

# Ideas
 - Main website with a daily curiosity
 - Facebook/Twitter bot to post the daily curiosity

## Contributing
Pull requests are welcome. For major changes, please open an issue first to discuss what you would like to change.
If you want to contribute with useless facts, email me at hugo.fellipe.cruz@gmail.com

## License
[MIT](https://choosealicense.com/licenses/mit/)

## Authors
Daniel Yuji Yamada - 10430920
Matheus Pecoraro de Carvalho Santos 11917271
Sungwon Yoon - 9822261
Hugo Fellipe - 10903872